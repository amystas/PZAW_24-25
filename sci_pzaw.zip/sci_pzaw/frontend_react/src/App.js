import logo from './logo.svg';
import './App.css';
import {useEffect, useState} from 'react';
import axios from 'axios'

function App() {
  const [images, setImages] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategories, setSelectedCategories] = useState([]);
  useEffect(() => {
    axios.get("http://localhost:8000/data")
    .then(response => response.data)
    .then(data => setImages(data));
  }, [])

  const filtredImages = images.filter(image => 
    (image.text.toLowerCase().includes(searchQuery.toLowerCase())) 
  )

  const filterByCategory = (category) => {
    if(selectedCategories.includes(category)) {
      setSelectedCategories(selectedCategories.filter(c => c !== category));
    } else {
      selectedCategories.push(category);
    }
  }
  
  const categoryNames = Array.from(new Set(filtredImages.map((image) => image.filename.split("_")[0])));
  return (
    <>
    <input type="text" class="form-control" value={searchQuery} onChange={e => setSearchQuery(e.target.value)}></input>
    <input type="range" min="1" max="5"/>
    {categoryNames.map((name) => (
      <><input type="checkbox" key={name.id} autoComplete="off" onChange={filterByCategory(name)}/><label>{name}</label></>
    ))}
    <div class="row row-cols-5">
      {filtredImages.map((image) => (
          <div key={image.id} class="col">
              <div class="card">
                <img src={"cards/" + image.filename + "." + image.extension} class="card-img-top"/>
                <div class="card-body">
                  <p class="card-text">{image.text}</p>
                </div>
              </div>
          </div>
      ))}
    </div>
    </>
  );
}

export default App;
