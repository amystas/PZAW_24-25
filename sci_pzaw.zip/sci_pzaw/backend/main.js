const cors = require('cors');
const express = require('express');
const fs = require('fs');

const app = express();

app.use(cors());
app.use(express.json());

app.get('/data', (req, res) => {
    fs.readFile("_data.json", "utf8", (err, data) => {
        const images = JSON.parse(data);
        res.json(images);
    })
});

app.listen(8000, () => {
    console.log('Server listening');
});
